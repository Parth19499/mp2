<?php
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$name=$_POST['name'];
	$image=basename( $_FILES["profpic"]["name"],".jpg");
	$dob=htmlentities($_POST['dob']);
	// $image=file_get_contents($_FILES['image']['profpic']);
	$hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
	$db = 'mp2login';
	$connection = new mysqli('localhost','root','',$db) or die("connection failed");
	// $sql1="";
	// if(mysql_query($connection,$sql1))
	$sql="insert into userdetails values('".$name."','".$email."','".$hashed_pass."','".$dob."','".$image."')";
	if(mysqli_query($connection,$sql)){
		echo "success!!!";
		print '<script type="text/javascript">';
		print 'alert("The data is inserted!!!")';
		print '</script>';
	}
	else{
		echo "user already exists!!!";
	}
	// fuction callMe(){
	// 	$myq="SELECT * FROM userdetails where email='zx@d.c'";
	// 	$sth=$db->query($myq);
	// 	$result=mysqli_fetch_array($sth);
	// 	echo '<img src="data:image/jpeg;base64'.base64_encode($result['image']).'"/>';
		
	// }
	$connection->close();
?>