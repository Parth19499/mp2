<?php
	$db = 'smarthea_mp2';
	$con = new mysqli('localhost','smarthea_Parth','Parth@19499',$db) or die("connection failed");
	echo"connection established!!!";
?>