alert(document.getElementById("email").innerHTML);
var email = document.getElementById("email").innerHTML;
alert("email");