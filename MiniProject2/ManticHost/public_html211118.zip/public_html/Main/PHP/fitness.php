<?
    session_start();
    // $_SESSION["validate_session"] contains email
    
?>